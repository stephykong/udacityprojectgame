frontend-nanodegree-arcade-game
===============================

###Instructions
1. To load the game, open the file labeled frontend-nanodegree-arcade-game-master 5/Final Game Draft 2 from file folder onto Google Chrome or normal website and access the file index.html.
2. Once opened, there are several sectors of code. One sector establishes the player and enemy variables.
3. These variables tell what the characters involved in the game do.
4. There are several functions (e.g., render that helps with the movement and implementation of graphics of the page)
5. The key handling at the bottom describes the movement of the characters and the collision functions describe when a bug collides with something, which prompts the reset buttons.
6. If you make it to the water, you win the game.
